package com.shourya.demo.model;

public class Response {

    String message;
    Integer code;

    public Response(String message, Integer code) {
        this.message = message;
        this.code = code;
    }
}
