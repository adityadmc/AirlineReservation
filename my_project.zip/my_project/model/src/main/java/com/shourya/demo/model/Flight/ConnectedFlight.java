package com.shourya.demo.model.Flight;


public class ConnectedFlight {
}
