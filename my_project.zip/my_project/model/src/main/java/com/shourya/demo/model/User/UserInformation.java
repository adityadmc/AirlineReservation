package com.shourya.demo.model.User;

public class UserInformation {
}
