package com.shourya.demo.persistance.repository;

import com.shourya.demo.persistance.entity.Luggage;

public interface LuggageRepository extends BaseRepo<Luggage,Integer> {

}
