package com.shourya.demo.core.service;

import com.shourya.demo.model.City.CityDTO;

import java.util.Collection;

public interface CityService {

    Collection<CityDTO> getCityDetails();

}
